# 🏠 LANDING_PAGE_SPEC.md — InvoicePK Landing Page Implementation

> `LAUNCH_STRATEGY.md` defines what sections the landing page needs and the copy to
> use. This document defines how to actually build it — component breakdown, layout,
> and code. Read both together; this one assumes you've already read the section
> order and FAQ content in `LAUNCH_STRATEGY.md`.

---

## Why the Landing Page Has Its Own Layout

Per `GLOBAL_LAYOUT.md`, the landing page does not use the `(dashboard)` shell
(Navbar + Sidebar) or the `(auth)` shell (centered form). It's public, unauthenticated,
and needs full-bleed sections (hero, pricing) that the dashboard's max-width content
wrapper would constrain awkwardly. It lives directly at `app/page.tsx` with its own
header.

```
app/
├── page.tsx                  ← Landing page, own layout, no shell
├── (auth)/                   ← Shell: centered form
└── (dashboard)/              ← Shell: Navbar + Sidebar
```

---

## Component Breakdown

```
components/Landing/
├── index.tsx                 ← assembles all sections in order
├── Header/
│   └── index.tsx             (public header — Login/Get Started, not the auth Navbar)
├── Hero/
│   └── index.tsx
├── ProblemSection/
│   └── index.tsx
├── SolutionSection/
│   └── index.tsx
├── HowItWorks/
│   └── index.tsx
├── SamplePDFPreview/
│   └── index.tsx
├── PricingTable/
│   └── index.tsx
├── FAQ/
│   └── index.tsx
└── Footer/
    └── index.tsx
```

Add these to `COMPONENT_LIBRARY.md` once built, following the same entry format as
every other component — props interface and usage location.

---

## Public Header (Not the Dashboard Navbar)

The landing page needs its own header — different from `Navbar` (which is for
authenticated pages and includes `SearchBar`/`DropdownMenu`). This one is simpler:
logo, nav links, and Login/Get Started buttons.

```tsx
// components/Landing/Header/index.tsx
import { Logo } from '@/components/Navbar/Logo';
import Link from 'next/link';

export function LandingHeader() {
  return (
    <header className="border-b border-border">
      <div className="max-w-[1200px] mx-auto px-4 md:px-8 py-4 flex items-center justify-between">
        <Logo />
        <nav className="hidden md:flex items-center gap-6 text-sm text-text-secondary">
          <a href="#solution">Features</a>
          <a href="#pricing">Pricing</a>
          <a href="#faq">FAQ</a>
        </nav>
        <div className="flex items-center gap-3">
          <Link href="/login" className="text-sm font-medium text-text-primary">
            Login
          </Link>
          <Link href="/register" className="bg-primary text-white px-4 py-2 rounded-md text-sm font-medium">
            Get Started Free
          </Link>
        </div>
      </div>
    </header>
  );
}
```

> Note: `Logo` is reused from `components/Navbar/Logo` — no need to duplicate it.
> This is exactly the kind of reuse the atomic component structure in
> `FRONTEND_DEV.md` is meant to enable.

---

## Hero Section

```tsx
// components/Landing/Hero/index.tsx
import Link from 'next/link';

export function Hero() {
  return (
    <section className="max-w-[1200px] mx-auto px-4 md:px-8 py-16 md:py-24 text-center">
      <h1 className="text-3xl md:text-5xl font-bold text-text-primary mb-4 max-w-[700px] mx-auto">
        Generate FBR-Compliant GST Invoices in 2 Minutes
      </h1>
      <p className="text-lg text-text-secondary mb-8 max-w-[500px] mx-auto">
        Built for Pakistani freelancers. GST, WHT, NTN, and STRN — calculated
        correctly, every time. No accountant needed.
      </p>
      <Link
        href="/register"
        className="inline-block bg-primary text-white px-8 py-3 rounded-md text-base font-semibold hover:bg-primary-light"
      >
        Create Free Invoice
      </Link>
      <p className="text-sm text-text-muted mt-3">
        Free for up to 5 invoices/month. No credit card required.
      </p>
    </section>
  );
}
```

---

## Problem Section

Copy source: `LAUNCH_STRATEGY.md`'s "Still making invoices in Word?" framing.

```tsx
// components/Landing/ProblemSection/index.tsx
const painPoints = [
  {
    title: 'GST Calculations Go Wrong',
    description: 'Manual GST, WHT, and zero-rating math means errors that delay client payments.',
  },
  {
    title: 'Invoices Look Unprofessional',
    description: 'Word templates do not include NTN, STRN, or proper GST breakdowns.',
  },
  {
    title: 'FBR Compliance Is Confusing',
    description: 'Knowing when to apply WHT or zero-rate an export invoice is not obvious.',
  },
];

export function ProblemSection() {
  return (
    <section className="bg-surface py-16">
      <div className="max-w-[1200px] mx-auto px-4 md:px-8">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">
          Still making invoices in Word?
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {painPoints.map((point) => (
            <div key={point.title}>
              <h3 className="font-semibold text-lg mb-2">{point.title}</h3>
              <p className="text-text-secondary text-sm">{point.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
```

---

## Solution Section

```tsx
// components/Landing/SolutionSection/index.tsx
import { Calculator, FileDown, ShieldCheck } from 'lucide-react';

const features = [
  { icon: Calculator, title: 'GST Auto-Calculated', description: 'Standard, zero-rated, and exempt — calculated correctly every time, with WHT support for corporate clients.' },
  { icon: FileDown, title: 'Professional PDF Download', description: 'Logo, NTN, STRN, and a clean line-item breakdown — ready to send.' },
  { icon: ShieldCheck, title: 'FBR-Compliant by Default', description: 'Built around Pakistani tax rules from the ground up, not bolted on.' },
];

export function SolutionSection() {
  return (
    <section id="solution" className="py-16">
      <div className="max-w-[1200px] mx-auto px-4 md:px-8">
        <div className="grid md:grid-cols-3 gap-8">
          {features.map(({ icon: Icon, title, description }) => (
            <div key={title} className="text-center md:text-left">
              <Icon className="w-8 h-8 text-primary mb-3 mx-auto md:mx-0" />
              <h3 className="font-semibold text-lg mb-2">{title}</h3>
              <p className="text-text-secondary text-sm">{description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
```

---

## How It Works

```tsx
// components/Landing/HowItWorks/index.tsx
const steps = [
  { step: 1, title: 'Create Account', description: 'Sign up free in under a minute.' },
  { step: 2, title: 'Fill Invoice', description: 'Add client, line items — GST calculates live as you type.' },
  { step: 3, title: 'Download PDF', description: 'Get a professional, FBR-compliant invoice instantly.' },
];

export function HowItWorks() {
  return (
    <section className="bg-surface py-16">
      <div className="max-w-[1200px] mx-auto px-4 md:px-8">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">How It Works</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {steps.map(({ step, title, description }) => (
            <div key={step} className="text-center">
              <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center font-bold mx-auto mb-3">
                {step}
              </div>
              <h3 className="font-semibold mb-2">{title}</h3>
              <p className="text-text-secondary text-sm">{description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
```

> Note: this is one of the rare legitimate uses of numbered markers (1/2/3) per the
> `frontend-design` guidance — it's an actual sequence of steps the user performs in
> order, not decoration.

---

## Sample PDF Preview

```tsx
// components/Landing/SamplePDFPreview/index.tsx
import Image from 'next/image';

export function SamplePDFPreview() {
  return (
    <section className="py-16">
      <div className="max-w-[800px] mx-auto px-4 md:px-8 text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-4">See It In Action</h2>
        <p className="text-text-secondary mb-8">
          A real invoice generated by InvoicePK — every field FBR expects.
        </p>
        <div className="border border-border rounded-lg shadow-lg overflow-hidden">
          <Image
            src="/assets/sample-invoice-preview.png"
            alt="Sample InvoicePK invoice"
            width={800}
            height={1000}
            className="w-full h-auto"
          />
        </div>
      </div>
    </section>
  );
}
```

> The screenshot needs to be generated once a real invoice exists (Day 8-9 per
> `DEVELOPMENT_PLAN.md`, once the PDF route is live) and saved to
> `public/assets/sample-invoice-preview.png`. Use a realistic but clearly fake
> business/client name — don't use a real user's data.

---

## Pricing Table

Pricing values sourced from `LAUNCH_STRATEGY.md` — do not hardcode different numbers
here than what that document specifies.

```tsx
// components/Landing/PricingTable/index.tsx
import { Check } from 'lucide-react';
import Link from 'next/link';

const plans = [
  {
    name: 'Free',
    price: 'PKR 0',
    period: '/month',
    features: ['5 invoices/month', 'GST calculation', 'PDF download', '1 business profile', '10 clients'],
    cta: 'Get Started Free',
    href: '/register',
  },
  {
    name: 'Pro',
    price: 'PKR 999',
    period: '/month',
    features: ['Unlimited invoices', 'Everything in Free', 'Logo upload', 'PDF save to cloud', 'Dashboard stats'],
    cta: 'Upgrade to Pro',
    href: '/register?plan=pro',
    highlighted: true,
  },
];

export function PricingTable() {
  return (
    <section id="pricing" className="py-16">
      <div className="max-w-[800px] mx-auto px-4 md:px-8">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">Simple Pricing</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`border rounded-lg p-6 ${plan.highlighted ? 'border-primary border-2' : 'border-border'}`}
            >
              <h3 className="font-semibold text-lg mb-1">{plan.name}</h3>
              <p className="mb-4">
                <span className="text-3xl font-bold">{plan.price}</span>
                <span className="text-text-secondary text-sm">{plan.period}</span>
              </p>
              <ul className="space-y-2 mb-6">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm text-text-secondary">
                    <Check className="w-4 h-4 text-accent flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                href={plan.href}
                className={`block text-center py-2 rounded-md text-sm font-medium ${
                  plan.highlighted ? 'bg-primary text-white' : 'border border-border text-text-primary'
                }`}
              >
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
```

> The `?plan=pro` query param on the Pro CTA is read by the register page to
> pre-select a plan post-registration in Phase 2. For MVP, both buttons just lead to
> `/register` — Pro upgrade itself is not part of MVP scope (no payment integration
> yet, per `RISKS_AND_DECISIONS.md` and `LAUNCH_STRATEGY.md`'s Phase 2 roadmap).

---

## FAQ Section

Content sourced exactly from `LAUNCH_STRATEGY.md` — do not write new FAQ copy here,
reference that document's content directly.

```tsx
// components/Landing/FAQ/index.tsx
'use client';

import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  { q: 'Is InvoicePK free?', a: 'Yes, up to 5 invoices per month. Pro is PKR 999/month for unlimited.' },
  { q: 'Is it FBR compliant?', a: 'Yes. GST at 17%, zero-rated for IT exports, WHT support, NTN and STRN on PDF.' },
  { q: 'Do I need an STRN?', a: 'Only if you charge GST. You can use InvoicePK without an STRN for exempt or zero-rated invoices.' },
  { q: 'Can I bill in USD?', a: 'Yes. Each invoice can be PKR or USD.' },
  { q: 'Is my data safe?', a: 'Yes. Your data is stored securely and never shared.' },
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="faq" className="bg-surface py-16">
      <div className="max-w-[700px] mx-auto px-4 md:px-8">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
        <div className="space-y-2">
          {faqs.map((faq, i) => (
            <div key={faq.q} className="border border-border rounded-md">
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between px-4 py-3 text-left font-medium"
              >
                {faq.q}
                <ChevronDown className={`w-4 h-4 transition-transform ${openIndex === i ? 'rotate-180' : ''}`} />
              </button>
              {openIndex === i && (
                <p className="px-4 pb-3 text-sm text-text-secondary">{faq.a}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
```

> This is a Client Component (`'use client'`) because of the `useState` for the
> accordion toggle — see the Server vs Client decision rule in `DATA_FETCHING.md`.

---

## Footer

```tsx
// components/Landing/Footer/index.tsx
export function Footer() {
  return (
    <footer className="border-t border-border py-8">
      <div className="max-w-[1200px] mx-auto px-4 md:px-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-text-muted">
        <p>Made in Pakistan 🇵🇰</p>
        <div className="flex gap-6">
          <a href="/login">Login</a>
          <a href="/register">Get Started</a>
        </div>
      </div>
    </footer>
  );
}
```

---

## Assembling the Page

```tsx
// app/page.tsx — Server Component, no shell, no auth required
import { LandingHeader } from '@/components/Landing/Header';
import { Hero } from '@/components/Landing/Hero';
import { ProblemSection } from '@/components/Landing/ProblemSection';
import { SolutionSection } from '@/components/Landing/SolutionSection';
import { HowItWorks } from '@/components/Landing/HowItWorks';
import { SamplePDFPreview } from '@/components/Landing/SamplePDFPreview';
import { PricingTable } from '@/components/Landing/PricingTable';
import { FAQ } from '@/components/Landing/FAQ';
import { Footer } from '@/components/Landing/Footer';

export default function LandingPage() {
  return (
    <div>
      <LandingHeader />
      <Hero />
      <ProblemSection />
      <SolutionSection />
      <HowItWorks />
      <SamplePDFPreview />
      <PricingTable />
      <FAQ />
      <Footer />
    </div>
  );
}
```

This page has no user-specific data — per `DATA_FETCHING.md`'s caching guidance, it's
the one page in the app that can use Next.js's default caching/static generation
instead of `cache: 'no-store'`.

---

## SEO Basics

Per `LAUNCH_STRATEGY.md`'s SEO keyword targets, add metadata to the page:

```tsx
// app/page.tsx — add at the top, outside the component
export const metadata = {
  title: 'InvoicePK — FBR-Compliant GST Invoice Generator for Pakistani Freelancers',
  description: 'Generate professional, FBR-compliant GST invoices in 2 minutes. Built for Pakistani freelancers with GST, WHT, NTN, and STRN support. Free to start.',
};
```

---

## Build Checklist

- [ ] All 9 sections present in the exact order from `LAUNCH_STRATEGY.md`
- [ ] Pricing numbers match `LAUNCH_STRATEGY.md` exactly (PKR 0 / PKR 999)
- [ ] FAQ copy matches `LAUNCH_STRATEGY.md` exactly — not rewritten
- [ ] Uses `theme.ts` colors only — zero hardcoded hex
- [ ] `HowItWorks` numbered steps are justified (real sequence, not decoration)
- [ ] Mobile tested at 375px — grid sections stack to single column
- [ ] Metadata added for SEO
- [ ] Sample PDF screenshot uses fake/placeholder business data, not a real user's

---

*Last updated: June 2026 | Build this on or after Day 13 per DEVELOPMENT_PLAN.md*
